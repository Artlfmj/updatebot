//here the event starts
module.exports = client => {
    console.log(`You have been disconnected at ${new Date()}.`.red)
}

/** Template by Tomato#6966 | https://github.com/Tomato6966/Discord-Js-Handler-Template */
