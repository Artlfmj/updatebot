//here the event starts
module.exports = client => {
    console.log(`Reconnceting at ${new Date()}.`.bgYellow.black)
}


/** Template by Tomato#6966 | https://github.com/Tomato6966/Discord-Js-Handler-Template */
