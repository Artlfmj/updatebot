//here the event starts
module.exports = client => {
    console.warn();
}

/** Template by Tomato#6966 | https://github.com/Tomato6966/Discord-Js-Handler-Template */
